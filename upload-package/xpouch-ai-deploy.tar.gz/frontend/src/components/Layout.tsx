import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import MainChatLayout from '@/components/MainChatLayout'
import { SettingsDialog } from '@/components/SettingsDialog'
import { PersonalSettingsDialog } from '@/components/PersonalSettingsDialog'
import { useState, useEffect } from 'react'
import { useChatStore } from '@/store/chatStore'
import { useUserStore } from '@/store/userStore'
import { PageType } from './Sidebar'

export default function Layout() {
  const navigate = useNavigate()
  const location = useLocation()
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [isPersonalSettingsOpen, setIsPersonalSettingsOpen] = useState(false)
  const { messages } = useChatStore()
  const { fetchUser } = useUserStore()

  useEffect(() => {
    fetchUser()
  }, [fetchUser])

  // 根据当前路由判断 PageType，用于 Sidebar 高亮
  const getCurrentPageType = (): PageType => {
    const path = location.pathname
    if (path === '/') return 'home'
    if (path.startsWith('/chat')) return 'chat'
    if (path === '/history') return 'history'
    if (path === '/knowledge') return 'knowledge'
    if (path === '/create-agent') return 'create-agent'
    return 'home'
  }

  const handlePageChange = (page: PageType) => {
    switch (page) {
      case 'home':
        navigate('/')
        break
      case 'history':
        navigate('/history')
        break
      case 'knowledge':
        navigate('/knowledge')
        break
      case 'create-agent':
        navigate('/create-agent')
        break
      case 'chat':
        // 如果点击 Sidebar 的 "Back to Chat"，我们尝试回到最近的会话
        handleGoToChat()
        break
    }
  }

  const handleGoToChat = () => {
    const lastId = useChatStore.getState().lastActiveConversationId
    if (lastId) {
      navigate(`/chat/${lastId}`)
    } else {
      navigate('/chat/new')
    }
  }

  return (
    <MainChatLayout
      hasMessages={messages.length > 0} // 这个属性现在可能只用于手机端 Sidebar 的显示逻辑
      currentPage={getCurrentPageType()}
      onPageChange={handlePageChange}
      onCreateAgent={() => navigate('/create-agent')}
      onGoToChat={handleGoToChat}
      onSettingsClick={() => setIsSettingsOpen(true)}
      onPersonalSettingsClick={() => setIsPersonalSettingsOpen(true)}
    >
      <Outlet />
      
      <SettingsDialog
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      <PersonalSettingsDialog
        isOpen={isPersonalSettingsOpen}
        onClose={() => setIsPersonalSettingsOpen(false)}
      />
    </MainChatLayout>
  )
}
