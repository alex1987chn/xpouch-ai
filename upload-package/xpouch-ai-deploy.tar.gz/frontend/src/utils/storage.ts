// 生成唯一ID
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
}

export type ConversationHistory = any; // Deprecated, kept for legacy type compatibility if needed
